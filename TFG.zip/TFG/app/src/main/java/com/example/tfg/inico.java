package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class inico extends AppCompatActivity {
ImageView eli,cons,aña,edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inico);
        edit=findViewById(R.id.Editar);
        cons=findViewById(R.id.Consultar);
        eli=findViewById(R.id.Eliminar);
        aña= findViewById(R.id.Añadir);

    }

    public void Añadir_Inventario(View v)
    {
        Intent tres = new Intent(inico.this, Anadir_Inventario.class);
        startActivity(tres);
    }

    public void Buscar(View v)
    {
        Intent bus = new Intent(inico.this, busqueda.class);
        startActivity(bus);
    }
    public void Eliminar(View v)
    {
        Intent borr=new Intent(inico.this, Eliminar.class);
        startActivity(borr);
    }
    public void Modificar(View v)
    {
        Intent bus=new Intent(inico.this, Modificar.class);
        startActivity(bus);
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id =item.getItemId();
        if(id==R.id.Opcion1)
        {
            Intent firsto=new Intent(this,inico.class);
            startActivity(firsto);
            return true;
        }
        if(id==R.id.Opcion2)
        {
            Intent secondo=new Intent(this,Proveedores.class);
            startActivity(secondo);
            return true;
        }
        if (id==R.id.InfoApp)
        {
            Intent trechero=new Intent(this,Acerca_De.class);
            startActivity(trechero);
            return true;
        }


        return super.onOptionsItemSelected(item);

    }


}
