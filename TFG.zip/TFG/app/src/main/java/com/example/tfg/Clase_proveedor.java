package com.example.tfg;

public class Clase_proveedor
{
    private Integer id;
    private String nombre;
    private String telefono;
    private String categoria;

    public Clase_proveedor(Integer id, String nombre, String telefono, String categoria) {
        this.id = id;
        this.nombre = nombre;
        this.telefono = telefono;
        this.categoria = categoria;
    }

    public Clase_proveedor() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }


}
