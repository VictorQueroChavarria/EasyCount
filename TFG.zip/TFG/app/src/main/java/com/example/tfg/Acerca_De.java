package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class Acerca_De extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acerca__de2);
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id =item.getItemId();
        if(id==R.id.Opcion1)
        {
            Intent firsto=new Intent(this,inico.class);
            startActivity(firsto);
            return true;
        }
        if(id==R.id.Opcion2)
        {
            Intent secondo=new Intent(this,Proveedores.class);
            startActivity(secondo);
            return true;
        }
        if (id==R.id.InfoApp)
        {
            Intent trechero=new Intent(this,Acerca_De.class);
            startActivity(trechero);
            return true;
        }


        return super.onOptionsItemSelected(item);

    }
}
