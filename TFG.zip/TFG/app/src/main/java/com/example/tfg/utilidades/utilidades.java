package com.example.tfg.utilidades;

public class utilidades
{
    public static final String TABLA_proveedor="proveedor";
    public static final String  CAMPO_ID="id";
    public static final String CAMPO_NOMBRE="nombre";
    public static final String CAMPO_TELEF="telefono";
    public static final String CAMPO_CATEG="categoria";

    public static final String Crear_Tabla_Proveedor="Create table "+TABLA_proveedor+"("+CAMPO_ID+" Integer,"+CAMPO_NOMBRE+" text, "+CAMPO_TELEF+" text,"+CAMPO_CATEG+"  text)";


}
