package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Anadir_Inventario extends AppCompatActivity {
EditText eid,epre,ecan,epro,ecat;
Button next, back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anadir__inventario);
        eid=findViewById(R.id.Id);
        ecan=findViewById(R.id.Cantidad);
        epre=findViewById(R.id.Precio);
        epro=findViewById(R.id.Producto);
        ecat= findViewById(R.id.categoria);
        next=findViewById(R.id.aceptar2);
        back=findViewById(R.id.atras);


    }
    public void Añadir(View v){
        BaseDeDatosInventario admin= new BaseDeDatosInventario(this, "Producto", null, 1);
        SQLiteDatabase BasedeDatos= admin.getReadableDatabase();

        String valor_id= eid.getText().toString();
        String nom_producto= epro.getText().toString();
        String valor_cantidad= ecan.getText().toString();
        String categ=ecat.getText().toString();
        String valor_precio= epre.getText().toString();
        ContentValues contenido=new ContentValues();
        contenido.put("Id", valor_id);
        contenido.put("Producto", nom_producto);
        contenido.put("Cantidad",valor_cantidad);
        contenido.put("Categoria", categ);
        contenido.put("Precio", valor_precio);

        BasedeDatos.insert("inventario",null,contenido);
        BasedeDatos.close();

        Toast.makeText(this, "Usted inserto un producto ", Toast.LENGTH_LONG).show();
    }

    public void Back(View v){
        Intent volver= new Intent(Anadir_Inventario.this,inico.class);
        startActivity(volver);
    }


}
