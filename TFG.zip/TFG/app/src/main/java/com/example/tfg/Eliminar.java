package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Eliminar extends AppCompatActivity implements View.OnClickListener {
EditText esit;
Button borrar;
TextView ins;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminar);
        esit= (EditText) findViewById(R.id.editText);
        borrar= (Button) findViewById(R.id.Confirmar_Eliminacion);
        ins= (TextView) findViewById(R.id.Intrucciones);
        borrar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        BaseDeDatosInventario admin=new BaseDeDatosInventario(this,"Producto",null,1);

        SQLiteDatabase bd=admin.getReadableDatabase();
        String id=esit.getText().toString();
        if(!id.isEmpty())
        {
            int cantidad=bd.delete("inventario","id="+id,null);
            Toast.makeText(this, "He borrado "+cantidad, Toast.LENGTH_LONG).show();
            bd.close();
        } else{
            Toast.makeText(this, "Teclea un id valido", Toast.LENGTH_LONG).show();

        }
    }


    }
