package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class busqueda extends AppCompatActivity {
    EditText e1;
    TextView text,er;
    Button buscar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_busqueda);
        e1= (EditText) findViewById(R.id.editText3);
        text = (TextView) findViewById(R.id.textView4);
        er= (TextView) findViewById(R.id.Resultado);
        buscar= (Button) findViewById(R.id.Buscar);

    }
    public void Buscar(View view)
    {
        BaseDeDatosInventario admin=new BaseDeDatosInventario(this,"Producto",null,1);

        SQLiteDatabase bd=admin.getReadableDatabase();


        String id_producto=e1.getText().toString();
        if(!id_producto.isEmpty())
        {
            Cursor fila=bd.rawQuery("select producto, cantidad , categoria from inventario where id="+id_producto,null);
            if (fila.moveToFirst()){
                 er.setText("Producto: "+ fila.getString(0) + " Cantidad: " + fila.getInt(1) + " Categoria: " + fila.getString(2));
                 bd.close();
            }else{
                Toast.makeText(this, "No hay producto con ese id", Toast.LENGTH_LONG).show();
                bd.close();
            }
        }else{
            Toast.makeText(this, "Debes introducir un id de producto", Toast.LENGTH_LONG).show();
        }


    }
    public void Back(View v){
        Intent volver= new Intent(this, inico.class);
        startActivity(volver);
    }

}
