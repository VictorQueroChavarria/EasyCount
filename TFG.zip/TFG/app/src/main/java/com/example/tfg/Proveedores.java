package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.tfg.utilidades.utilidades;

import java.util.ArrayList;

public class Proveedores extends AppCompatActivity {
    ListView lista;
    ArrayList<String> list_proveedores;
    ArrayList<Clase_proveedor> lis;
    Button nuevo, borrar;

    BDProveedores con;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proveedores);
        lista = (ListView) findViewById(R.id.lista_proveedores);
        nuevo = (Button) findViewById(R.id.Añadir);
        borrar = (Button) findViewById(R.id.Borrar);


        con = new BDProveedores(getApplicationContext(), "proveedor", null, 1);
        consultaProveedores();
        ArrayAdapter<String> adaptor = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list_proveedores);
        lista.setAdapter(adaptor);
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,final int position, long id) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(Proveedores.this);
                alertDialog.setMessage("¿Desea realizar la llamada al contacto?");
                alertDialog.setTitle("Llamar a contacto...");
                alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
                alertDialog.setCancelable(false);
                alertDialog.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       try{
                           String number = lis.get(position).getTelefono();
                           Toast.makeText(getApplicationContext(), "LLamando al " + number, Toast.LENGTH_LONG).show();
                           Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse(number));
                           if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                               // TODO: Consider calling
                               //    ActivityCompat#requestPermissions
                               // here to request the missing permissions, and then overriding
                               //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                               //                                          int[] grantResults)
                               // to handle the case where the user grants the permission. See the documentation
                               // for ActivityCompat#requestPermissions for more details.
                               return;
                           }
                           startActivity(callIntent);
                       } catch (Exception e){
                           Toast.makeText(getApplicationContext(),
                                   "No se ha podido realizar la llamada", Toast.LENGTH_LONG).show();
                       }
                    }
                });
                alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        Toast.makeText(getApplicationContext(),
                                "Llamada cancelada", Toast.LENGTH_LONG).show();
                    }
                });
                alertDialog.show();
            }
        });
    }


    private void consultaProveedores()
    {
        SQLiteDatabase db=con.getReadableDatabase();

        Clase_proveedor pr=null;
        lis = new ArrayList<Clase_proveedor>();
        Cursor cursor = db.rawQuery("select * from "+ utilidades.TABLA_proveedor, null);
        while(cursor.moveToNext())
        {
            pr=new Clase_proveedor() ;
            pr.setId(cursor.getInt(0));
            pr.setNombre(cursor.getString(1));
            pr.setTelefono(cursor.getString(2));
            pr.setCategoria(cursor.getString(3));

            lis.add(pr);
        }
        sacarLista();
    }

    private void sacarLista()
    {
        list_proveedores =new ArrayList<String>();

        for(int i=0;i<lis.size();i++)
        {
            list_proveedores.add(lis.get(i).getId()+" - "+lis.get(i).getNombre()+" - "+lis.get(i).getTelefono()+" - "+lis.get(i).getCategoria());
        }
    }

    public void Agregar_Nuevo(View view)
    {
        Intent NEW =new Intent(this,NuevoProveedor.class);
        startActivity(NEW);
    }

    public void Borrar_Proveedor(View view)
    {
        Intent del=new Intent(Proveedores.this,Borrar_proveedor.class);
        startActivity(del);
    }






    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id =item.getItemId();
        if(id==R.id.Opcion1)
        {
            Intent firsto=new Intent(this,inico.class);
            startActivity(firsto);
            return true;
        }
        if(id==R.id.Opcion2)
        {
            Intent secondo=new Intent(this,Proveedores.class);
            startActivity(secondo);
            return true;
        }
        if (id==R.id.InfoApp)
        {
            Intent trechero=new Intent(this,Acerca_De.class);
            startActivity(trechero);
            return true;
        }


        return super.onOptionsItemSelected(item);

    }

}
