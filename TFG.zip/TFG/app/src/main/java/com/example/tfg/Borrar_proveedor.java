package com.example.tfg;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tfg.utilidades.utilidades;

public class Borrar_proveedor extends AppCompatActivity  {
TextView tex;
EditText ed;
Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrar_proveedor);
        tex = (TextView) findViewById(R.id.textView18);
        ed=(EditText) findViewById(R.id.borrrado);
        b=(Button) findViewById(R.id.button);

    }






    public void Borrar(View view) {
        BDProveedores admin  = new BDProveedores(this,"proveedor",null,1);
        SQLiteDatabase db=admin.getReadableDatabase();
        String id=ed.getText().toString();
        if(!id.isEmpty())
        {
            int cantidad=db.delete(utilidades.TABLA_proveedor,utilidades.CAMPO_ID+"="+id,null);
            Toast.makeText(this, "He borrado "+cantidad, Toast.LENGTH_LONG).show();
            db.close();
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
                Intent dos = new Intent(Borrar_proveedor.this, Proveedores.class);
                startActivity(dos);

            }
        },2500);
        }

    }


