package com.example.tfg;

import androidx.annotation.VisibleForTesting;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tfg.utilidades.utilidades;

public class NuevoProveedor extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {
TextView text;
EditText  nombre,telefono;
RadioGroup categoria;
RadioButton con,ali,bol;
Button volver,agregar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_proveedor);
        text= (TextView) findViewById(R.id.textView13);
        con=(RadioButton) findViewById(R.id.conge);
        ali=(RadioButton) findViewById(R.id.alim);
        bol=(RadioButton) findViewById(R.id.boll);
        nombre=(EditText) findViewById(R.id.nombre_proveedor);
        telefono=(EditText) findViewById(R.id.telefono_proveedor);
        categoria=(RadioGroup) findViewById(R.id.Categoria_proveedor);
        volver=(Button) findViewById(R.id.Volver_proveedores);
        agregar= (Button) findViewById(R.id.Agregar_proveedor);
        categoria.setOnCheckedChangeListener(this);
    }

    public void Regresar(View view)
    {
        Intent back=new Intent(this,Proveedores.class);
        startActivity(back);
    }

    public void añadir_proveedor(View view)
    {
        int id=0;
        id=id+1;
        BDProveedores admin  = new BDProveedores(this,"proveedor",null,1);
        SQLiteDatabase db=admin.getReadableDatabase();

        String cate="";
        if(con.isChecked()){
            cate="Congelados";
        }
        if(ali.isChecked()){
             cate="Alimentos";
        }
        if(bol.isChecked()){
            cate="Bolleria";
        }

        String nom_pro=nombre.getText().toString();
        String tel_pro=telefono.getText().toString();

        ContentValues contenido=new ContentValues();
        contenido.put(utilidades.CAMPO_ID,id);

        contenido.put(utilidades.CAMPO_NOMBRE,nom_pro);
        contenido.put(utilidades.CAMPO_TELEF,tel_pro);
        contenido.put(utilidades.CAMPO_CATEG, cate );
        db.insert(utilidades.TABLA_proveedor,utilidades.CAMPO_ID,contenido);
        db.close();

        Toast.makeText(this, "Proveedor agregado exitosamente ", Toast.LENGTH_LONG).show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
                Intent dos = new Intent(NuevoProveedor.this, Proveedores.class);
                startActivity(dos);

            }
        },2500);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        if(con.isChecked()){
            String categoria="Congelados";
        }
        if(ali.isChecked()){
            String categoria="Alimentos";
        }
        if(bol.isChecked()){
            String categoria="Bolleria";
        }
    }
}
