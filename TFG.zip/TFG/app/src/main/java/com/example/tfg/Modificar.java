package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Modificar extends AppCompatActivity {
    EditText eid,epre,ecan,epro,ecat;
    Button next, back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar);
        eid=findViewById(R.id.Id);
        ecan=findViewById(R.id.Cantidad);
        epre=findViewById(R.id.Precio);
        ecat= findViewById(R.id.categoria);
        epro=findViewById(R.id.Producto);
        next=findViewById(R.id.aceptar);
        back=findViewById(R.id.atras);
    }

    public void Back(View v){
        Intent volver= new Intent(Modificar.this,inico.class);
        startActivity(volver);
    }
    public void modificar(View view)
    {
        BaseDeDatosInventario admin= new BaseDeDatosInventario(this,"Producto",null,1);
        SQLiteDatabase bd=admin.getReadableDatabase();
        String valor_id= eid.getText().toString();
        String nom_producto= epro.getText().toString();
        String valor_cantidad= ecan.getText().toString();
        String categoria= ecat.getText().toString();
        String valor_precio= epre.getText().toString();
        if (!valor_id.isEmpty() && !nom_producto.isEmpty() && valor_cantidad.isEmpty() && valor_precio.isEmpty())
        {
            ContentValues contenido=new ContentValues();
            contenido.put("Id", valor_id);
            contenido.put("Producto", nom_producto);
            contenido.put("Cantidad",valor_cantidad);
            contenido.put("Categoria", categoria);
            contenido.put("Precio", valor_precio);

            int cantidad=bd.update("inventario",contenido,"id="+valor_id,null);
            Toast.makeText(this, "He modificado "+cantidad, Toast.LENGTH_LONG).show();
            bd.close();
        }else {
            Toast.makeText(this, "Debes ingresar todos los valores", Toast.LENGTH_LONG).show();
        }
    }
}
